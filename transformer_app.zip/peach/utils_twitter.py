import spacy
import wordsegment
# from spacy_langdetect import LanguageDetector
nlp = spacy.load("en_core_web_sm", disable=["tagger", "ner", "parse"])

# import demoji
# demoji.download_codes()

def process_tweet(sent_text, remove_emoji=False, remove_user=False, remove_tag=False, replace_tag=False):
    # replace @xxxx to user

    # replace
    sent_text = sent_text.replace("&quot;", "\"").replace("&amp;", "&").replace(
        "&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")

    sent_text = sent_text.replace("\n", " ")
    sent_text = sent_text.replace("\t", " ")

    # if remove_emoji:
    #     sent_text = demoji.replace(sent_text)

    doc = nlp(sent_text)

    # detect language
    if len(doc) == 0:
        return None
    # if doc._.language["language"] != "en":
    #     return None

    # replace @xx and remove url
    user_dict = dict()
    str_list = []

    skip_flag = False
    for token in doc:
        token_str = token.text.strip()

        if skip_flag:
            skip_flag = False
            if replace_tag:
                str_list.append(token.text)
            else:
                continue
        elif token.like_url or token.like_email:
            continue
        elif token_str.startswith("@"):
            if token_str not in user_dict:
                user_dict[token_str] = str(len(user_dict))
            replace_str = "User{}".format(user_dict[token_str])
            if not remove_user:
                str_list.append(replace_str)
        elif remove_tag and token_str.startswith("#"):
            skip_flag = True  # also skip the next one
            continue
        else:
            str_list.append(token.text)
        str_list.append(token.whitespace_)
    return "".join(str_list).strip()
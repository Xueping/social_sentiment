import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import argparse
from tqdm import tqdm, trange
from transformers import BertConfig, BertTokenizer, BertForSequenceClassification, BertPreTrainedModel, BertModel


class BertForMultiLabelCls(BertPreTrainedModel):
    def __init__(self, config):
        super(BertForMultiLabelCls, self).__init__(config)

        self.num_labels = getattr(config, "num_labels", 2)
        self.pos_gain = getattr(config, "pos_gain", 1.)

        self.bert = BertModel(config)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.classifier = nn.Linear(config.hidden_size, self.num_labels * 2)  # !!!

        self.loss_weight_list = [1., float(self.pos_gain)]

    def forward(self, input_ids=None, attention_mask=None, token_type_ids=None,
                position_ids=None, head_mask=None, inputs_embeds=None, labels=None):
        outputs = self.bert(input_ids,
                            attention_mask=attention_mask,
                            token_type_ids=token_type_ids,
                            position_ids=position_ids,
                            head_mask=head_mask,
                            inputs_embeds=inputs_embeds)
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)
        logits = logits.view([-1, self.num_labels, 2])
        outputs = (logits,) + outputs[2:]  # add hidden states and attention if they are here

        if labels is not None:
            loss_fct = nn.CrossEntropyLoss(
                weight=torch.tensor(self.loss_weight_list, dtype=logits.dtype, device=logits.device),
                reduction="none",
            )
            logits_rsp = logits.view([-1, 2])
            labels_rsp = logits.view([-1])
            losses_rsp = loss_fct(logits_rsp, labels_rsp)
            losses = losses_rsp.view([-1, self.num_labels])
            losses = torch.mean(losses, dim=-1)
            loss = torch.mean(losses)
            outputs = (loss,) + outputs

        return outputs  # (loss), logits, (hidden_states), (attentions)




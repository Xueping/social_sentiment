import os
import torch
import random
import logging
import logging as logger
try:
    from torch.utils.tensorboard import SummaryWriter
except:
    from tensorboardX import SummaryWriter
from transformers import get_linear_schedule_with_warmup


class EmptyScheduler(object):
    def __init__(self, *args, **kwargs):
        pass

    def step(self):
        pass

    def get_lr(self):
        return [None]


def setup_opt_scratch(args, model):
    # Prepare optimizer and schedule (linear warmup and decay)
    # no_decay = ['bias', 'LayerNorm.weight']
    # optimizer_grouped_parameters = [
    #     {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
    #      'weight_decay': args.weight_decay},
    #     {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}
    # ]
    if args.adam_betas is not None:
        adam_betas = tuple(float(_f) for _f in args.adam_betas.split(","))
        assert len(adam_betas) == 2
    else:
        adam_betas = (0.9, 0.999)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate,
                                 betas=adam_betas, eps=args.adam_epsilon)
    # optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate,
    #                   betas=adam_betas, eps=args.adam_epsilon)
    # scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=args.warmup_steps, num_training_steps=args.t_total)
    scheduler = EmptyScheduler(optimizer, num_warmup_steps=args.warmup_steps, num_training_steps=args.t_total)
    if args.fp16:
        try:
            from apex import amp
        except ImportError:
            raise ImportError("Please install apex from https://www.github.com/nvidia/apex to use fp16 training.")
        model, optimizer = amp.initialize(model, optimizer, opt_level=args.fp16_opt_level)

    # multi-gpu training (should be after apex fp16 initialization)
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)

    # Distributed training (should be after apex fp16 initialization)
    if args.local_rank != -1:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank],
                                                          output_device=args.local_rank,
                                                          find_unused_parameters=True)
    return model, optimizer, scheduler



def save_model(output_dir, model, filename=None, args_to_save=None):
    # Create output directory if needed
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    logger.info("Saving model checkpoint to %s", output_dir)
    # Save a trained model, configuration and tokenizer using `save_pretrained()`.
    # They can then be reloaded using `from_pretrained()`
    model_to_save = model.module if hasattr(model, 'module') else model  # Take care of distributed/parallel training

    output_model_file = os.path.join(output_dir, filename or "pytorch_model.bin")
    torch.save(model_to_save.state_dict(), output_model_file)
    logger.info("Model weights saved in {}".format(output_model_file))

    # Good practice: save your training arguments together with the trained model
    if args_to_save is not None:
        torch.save(args_to_save, os.path.join(output_dir, 'training_args.bin'))


def load_model(output_dir, model, filename=None):
    model_file = os.path.join(output_dir, filename or "pytorch_model.bin")
    assert os.path.exists(model_file)
    logger.info("Loading model from file")
    model.load_state_dict(torch.load(model_file))
    logger.info("Model weights loaded from {}".format(model_file))
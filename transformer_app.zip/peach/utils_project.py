import argparse
import csv
import collections
from tqdm import tqdm
# import sklearn.metrics as metrics
import numpy as np
from peach.common import USER_HOME, file_exists, dir_exists, load_pickle, save_pickle
from peach.help import *
from torch.utils.data import TensorDataset, Dataset
# from proj.utils import multi_process_wrap, SingleSentDataset, train

from transformers import RobertaConfig, RobertaTokenizer
from transformers import BertConfig, BertTokenizer

from transformers import RobertaForSequenceClassification, BertForSequenceClassification


class SingleSentDataset(Dataset):
    def __init__(self, data_iter, tokenizer, max_seq_length, int_label_dtype=True, *args, **kwargs):
        for _k, _v in kwargs.items():
            setattr(self, _k, _v)
        self.tokenizer, self.max_seq_length = tokenizer, max_seq_length
        self.int_label_dtype = int_label_dtype

        self.example_list = []

        for _sents, _lb in data_iter:
            self.example_list.append(
                [_sents, _lb]
            )
        self.pad_id = self.tokenizer.convert_tokens_to_ids([self.tokenizer.pad_token])[0]

    def __getitem__(self, item):
        sents, label = self.example_list[item]
        return_list = []

        for sent in sents:
            tks = self.tokenizer.tokenize(sent)
            tks = tks[:self.max_seq_length-2]
            tks = [self.tokenizer.cls_token] + tks + [self.tokenizer.sep_token]
            input_ids = self.tokenizer.convert_tokens_to_ids(tks)
            mask_ids = [1] * len(input_ids)
            return_list.append(input_ids)
            return_list.append(mask_ids)
        return_list.append(label)

        if self.int_label_dtype:
            lt = torch.long
        else:
            lt = torch.float32

        return_tuple = tuple(torch.tensor(_e, dtype=torch.long) for _e in return_list[:-1])
        return_tuple += (torch.tensor(return_list[-1], dtype=lt), )

        return return_tuple

    def __len__(self):
        return len(self.example_list)

    def data_collate_fn(self, batch):
        tensors_list = list(zip(*batch))
        return_list = []
        for _idx_t, _tensors in enumerate(tensors_list):
            if _idx_t == 0:
                padding_value = self.pad_id
            else:
                padding_value = 0

            if _tensors[0].dim() >= 1:
                _tensors = [_t.t() for _t in _tensors]
                return_list.append(
                    torch.nn.utils.rnn.pad_sequence(
                        _tensors, batch_first=True, padding_value=padding_value),  # .transpose(-1, -2)
                )
            else:
                return_list.append(torch.stack(_tensors, dim=0))
        return tuple(return_list)

    @classmethod
    def batch2feed_dict(cls, batch, data_format=None):
        inputs = {
            'input_ids': batch[0],  # bs, sl
            'attention_mask': batch[1],  #
            "labels": batch[-1],  #
        }
        return inputs


class SentClsInterface(object):
    def __init__(self, model_dir, use_cuda=True, use_fp16=True, batch_size=160):
        training_args = torch.load(os.path.join(model_dir, "training_args.bin"))

        if training_args.model_class == "roberta":
            model_class = RobertaForSequenceClassification
            config_class = RobertaConfig
            tokenizer_class = RobertaTokenizer
        elif training_args.model_class == "bert":
            model_class = BertForSequenceClassification
            config_class = BertConfig
            tokenizer_class = BertTokenizer
        else:
            raise NotImplementedError

        self.model_dir = model_dir
        self.use_cuda = use_cuda
        self.use_fp16 = use_fp16
        self.batch_size = batch_size

        self.do_lower_case = training_args.do_lower_case
        self.max_seq_length = training_args.max_seq_length
        self.fp16_opt_level = training_args.fp16_opt_level

        self.config = config_class.from_pretrained(model_dir)
        self.tokenizer = tokenizer_class.from_pretrained(
            model_dir, do_lower_case=self.do_lower_case)
        self.model = model_class.from_pretrained(model_dir, config=self.config)
        self.model, self.device = setup_eval_model_for_inference(self.model, use_cuda, use_fp16, self.fp16_opt_level)
        self.model.eval()

    def prepare_dataloader(self, sent_list):
        if len(sent_list) > 0 and isinstance(sent_list[0], str):
            sent_list = [[s] for s in sent_list]

        ssd = SingleSentDataset([[sent, 0] for sent in sent_list], self.tokenizer, self.max_seq_length)
        dl = DataLoader(
            ssd, sampler=SequentialSampler(ssd), batch_size=self.batch_size, collate_fn=ssd.data_collate_fn)
        return ssd, dl

    def classify_sents(self, sent_list, verbose=False):
        ssd, dl = self.prepare_dataloader(sent_list)

        probs_list = []
        for batch in tqdm(dl, disable=not verbose):
            batch = tuple(_t.to(self.device) for _t in batch)
            feed_dict = ssd.batch2feed_dict(batch)

            with torch.no_grad():
                outputs = self.model(**feed_dict)
                loss, logits = outputs[:2]
                probs = torch.softmax(logits, dim=-1)
                probs_list.append(probs.detach().cpu().numpy())
        all_probs = np.concatenate(probs_list, axis=0)
        return all_probs


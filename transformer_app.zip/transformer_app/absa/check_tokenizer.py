from transformers import BertTokenizer, RobertaTokenizer
tk_bert_cased = BertTokenizer.from_pretrained("bert-large-cased")
tk_bert_uncased = BertTokenizer.from_pretrained("bert-large-uncased")
tk_roberta = RobertaTokenizer.from_pretrained("roberta-large")

sents = [
    "just watched '' raising arizona '' again - forgot how much i love that movie . back when $T$ made good movies ...",
    "Waiting for $T$ james franco is but that video of the chick on jay keno was funny the gardners face was priceless",
    "Where Gabriela personaly greets you and recommends you what to eat.",
    "a b c b 😭 dd ee",
]

for sent in sents:
    print("="*20)
    print("="*20)
    print("org:", sent)
    for tokenizer in [tk_bert_cased, tk_bert_uncased, tk_bert_uncased.basic_tokenizer, tk_bert_cased.basic_tokenizer]:
        print("-"*10)
        print(tokenizer.tokenize(tk_bert_cased.cls_token + " " +  sent + " " + tk_bert_cased.sep_token))
        # print(tokenizer.convert_tokens_to_string(tokenizer.tokenize(sent)))
        # print(tokenizer.encode(sent, add_special_tokens=False))
        # print(tokenizer.decode(tokenizer.encode(sent, add_special_tokens=False)))





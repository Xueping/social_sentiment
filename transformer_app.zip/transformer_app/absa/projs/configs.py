

model_dir_dict = {
    # sentment-level sentiment analysis model dir
    "slsa": "/home/tashen/PycharmProjects/transformer_app/runtime/absa/ausai_exp-roberta-large/ausai_exp-repeat-sst32doh-sent/sst32doh/datasetsst32doh-lr1.3e-5-roberta-large-bs32-epoch3-0-seed21",
    # aspect-based sentiment analysis model dir
    "absa": "/home/tashen/PycharmProjects/transformer_app/runtime/absa/ausai_exp-roberta-large/ausai_exp-repeat-all2doh-naive/all2doh/datasetall2doh-lr7E-6-roberta-large-bs32-epoch3-0-seed21",
    # sarcasm detection model dir
    "sd": "/home/tashen/PycharmProjects/transformer_app/runtime/absa/repeat-roberta-sarcasm-sent/datasetsarcasm-lr1.3e-5-roberta-large-bs32-epoch5-0-seed21",
}




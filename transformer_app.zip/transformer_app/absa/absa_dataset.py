from torch.utils.data import Dataset, DataLoader
from lxml import etree
from peach.common import load_list_from_file, USER_HOME, load_json, save_json, file_exists
from peach.utils_tokenizer import split_to_token, parse_tk_idx_list_wrt_char, continue_tokenize_for_wordpiece, char_to_token_span
import torch, os
import pandas as pd
import csv
from peach.utils_twitter import process_tweet
import logging as logger
from tqdm import tqdm, trange


def read_semeval14_absa_xml(xml_path):
    absa_dataset = []

    with open(xml_path, 'rb') as f:
        raw = f.read()
    root = etree.fromstring(raw)
    for sentence in root:
        sample = {}
        # get sent id
        sample["sent_id"] = sentence.attrib["id"]
        sample["sent_text"] = sentence.find('text').text
        # items
        sample["terms"] = []
        terms = sentence.find('aspectTerms')
        if terms is not None:
            for term in terms:
                term_dict = dict(term.attrib)
                term_dict["from"] = int(term_dict["from"])
                term_dict["to"] = int(term_dict["to"])
                sample["terms"].append(term_dict)
        # categories
        sample["categories"] = []
        categories = sentence.find('aspectCategories')
        if categories is not None:
            for category in categories:
                sample["categories"].append(dict(category.attrib))

        absa_dataset.append(sample)
    return absa_dataset


def read_twitter_absa_dataset(data_path):
    absa_dataset = []

    raw_data = load_list_from_file(data_path)
    assert len(raw_data) % 3 == 0

    for i in range(0, len(raw_data), 3):
        sent_text_with_ph = raw_data[i]
        term = raw_data[i+1]
        polarity_int = raw_data[i+2]

        if polarity_int == "-1":
            polarity = "negative"
        elif polarity_int == "0":
            polarity = "neutral"
        elif polarity_int == "1":
            polarity = "positive"
        else:
            raise AttributeError(polarity_int)

        from_idx = sent_text_with_ph.find("$T$")
        to_idx = from_idx + len(term)
        sent_text = sent_text_with_ph.replace("$T$", term)

        sample = {
            "sent_id": str(i//3), "sent_text": sent_text,
            "terms": [{"term": term, "polarity": polarity, "from": from_idx, "to": to_idx}],
            "categories": [],
        }
        absa_dataset.append(sample)
    return absa_dataset


def read_utstwitter_absa_dataset(data_path):
    absa_dataset = []

    df = pd.read_csv(data_path)
    labels = df["attitude"].values
    sent_list = []
    for s in df["text"].values:
        s_proc = process_tweet(s, remove_emoji=True, remove_user=True, remove_tag=True, replace_tag=True)
        assert s_proc is not None, (s, s_proc)
        sent_list.append(s_proc)
    for idx, (sent, lb) in enumerate(zip(sent_list, labels)):
        lb = int(lb)
        if lb == -1:
            polarity = "negative"
        elif lb == 0:
            polarity = "neutral"
        elif lb == 1:
            polarity = "positive"
        else:
            raise AttributeError

        sample = {
            "sent_id": str(idx), "sent_text": sent,
            "terms": [{"term": "CovidSafe App", "polarity": polarity, "from": -1, "to": -1}],
            "categories": [],
        }
        absa_dataset.append(sample)
    return absa_dataset


def read_dohtwitter_absa_dataset(data_path):
    absa_dataset = []

    df = pd.read_csv(data_path)
    labels = df["Sentiment"].values
    sent_list = []
    for s in df["tweet_text"].values:
        s_proc = process_tweet(s, remove_emoji=True, remove_user=True, remove_tag=True, replace_tag=True)
        assert s_proc is not None, (s, s_proc)
        sent_list.append(s_proc)
    for idx, (sent, lb) in enumerate(zip(sent_list, labels)):
        try:
            lb = int(lb)
            assert lb in [-1, 0, 1]
        except ValueError:
            continue
        except AssertionError:
            continue
        if lb == -1:
            polarity = "negative"
        elif lb == 0:
            polarity = "neutral"
        elif lb == 1:
            polarity = "positive"
        else:
            raise AttributeError
        sample = {
            "sent_id": "dohtwitter-" + str(idx), "sent_text": sent,
            "terms": [{"term": "CovidSafe App", "polarity": polarity, "from": -1, "to": -1}],
            "categories": [],
        }
        absa_dataset.append(sample)
    return absa_dataset


def read_sentiment140_normal_dataset(data_path):
    proc_path = data_path + ".proc.json"
    if file_exists(proc_path):
        absa_dataset = load_json(proc_path)
    else:
        raw_sent_list, label_list = [], []
        with open(data_path, encoding="latin-1") as csvfile:
            reader = csv.reader(csvfile)
            for idx_r, row in enumerate(tqdm(reader, total=1600000, desc="loading training data")):
                label = row[0]
                if label == "0":
                    label_int = "negative"
                elif label == "4":
                    label_int = "positive"
                else:
                    logger.info("label is", label, "-- discarded")
                    continue
                sent = row[-1]
                sent = process_tweet(sent, remove_emoji=True, remove_user=True, remove_tag=True, replace_tag=True)
                # sent = process_tweet(row[-1])
                # if sent is None:
                #     continue
                # if idx_r < 100:
                #     print(sent, label_int)
                raw_sent_list.append(sent)
                label_list.append(label_int)
        absa_dataset = []
        for idx, (sent_text, polarity) in enumerate(zip(raw_sent_list, label_list)):
            sample = {
                "sent_id": "sentiment140-"+str(idx), "sent_text": sent_text,
                "terms": [{"term": None, "polarity": polarity, "from": -1, "to": -1}],
                "categories": [],
            }
            absa_dataset.append(sample)
        save_json(absa_dataset, proc_path)
    return absa_dataset


def read_sst_normal_dataset(data_path, *arg, **kwargs):
    basename = os.path.basename(data_path)
    assert basename in ["train", "dev", "test"]
    data_path = os.path.dirname(data_path)
    # str2id
    str2id = {}
    with open(os.path.join(data_path, "dictionary.txt"), encoding="utf-8") as fp:
        for idx, line in enumerate(fp):
            if idx == 0:
                continue
            data = line.strip().split("|")
            assert len(data) == 2
            str2id[data[0]] = data[1]
    # id2label
    id2label = {}
    with open(os.path.join(data_path, "sentiment_labels.txt"), encoding="utf-8") as fp:
        offset = kwargs.get("offset")
        if offset is None:
            offset = 0.1
        for idx, line in enumerate(fp):
            if idx == 0:
                continue
            data = line.strip().split("|")
            assert len(data) == 2
            val = float(data[1])
            if val < 0.5 - offset:
                label = 0
            elif val < 0.5 + offset:
                label = 1
            else:
                label = 2
            id2label[data[0]] = label

    # sentidx2set
    sentidx2setname = dict(
        (_l.split(",")) for _l in load_list_from_file(os.path.join(data_path, "datasetSplit.txt"))[1:])
    for sentidx, sentname in sentidx2setname.items():
        if sentname == "1":
            sentidx2setname[sentidx] = "train"
        elif sentname == "2":
            sentidx2setname[sentidx] = "test"
        elif sentname == "3":
            sentidx2setname[sentidx] = "dev"
        else:
            raise AttributeError(sentidx, sentname)

    absa_dataset = []
    with open(os.path.join(data_path, "datasetSentences.txt"), encoding="utf-8") as fp:
        for idx, line in enumerate(fp):
            if idx == 0:
                continue
            data = line.strip().split("\t")
            assert len(data) == 2

            if sentidx2setname[data[0]] != basename:
                continue

            sent_idx = int(data[0])
            sent_text = data[1]
            try:
                _id = str2id[sent_text]
                label = id2label[_id]
            except KeyError:  # fixme: the text encoding
                pass

            if label == 0:
                polarity = "negative"
            elif label == 1:
                polarity = "neutral"
            elif label == 2:
                polarity = "positive"
            else:
                raise AttributeError

            sample = {
                "sent_id": "sst-"+str(sent_idx), "sent_text": sent_text,
                "terms": [{"term": None, "polarity": polarity, "from": -1, "to": -1}],
                "categories": [],
            }
            absa_dataset.append(sample)
    return absa_dataset


def read_psst_normal_dataset(data_path):
    # str2id
    str2id = {}
    with open(os.path.join(data_path, "dictionary.txt"), encoding="utf-8") as fp:
        for idx, line in enumerate(fp):
            if idx == 0:
                continue
            data = line.strip().split("|")
            assert len(data) == 2
            str2id[data[0]] = data[1]
    # id2label
    id2label = {}
    with open(os.path.join(data_path, "sentiment_labels.txt"), encoding="utf-8") as fp:
        for idx, line in enumerate(fp):
            if idx == 0:
                continue
            data = line.strip().split("|")
            assert len(data) == 2
            val = float(data[1])
            offset = 0.1
            if val < 0.5 - offset:
                label = 0
            elif val < 0.5 + offset:
                label = 1
            else:
                label = 2
            id2label[data[0]] = label

    absa_dataset = []
    for text, text_id in str2id.items():
        label = id2label[text_id]
        if label == 0:
            polarity = "negative"
        elif label == 1:
            polarity = "neutral"
        elif label == 2:
            polarity = "positive"
        else:
            raise AttributeError

        sample = {
            "sent_id": "psst-"+str(text_id), "sent_text": text,
            "terms": [{"term": None, "polarity": polarity, "from": -1, "to": -1}],
            "categories": [],
        }
        absa_dataset.append(sample)

    return absa_dataset


def read_semeval2018task3_sarcasm_dataset(data_path):
    absa_dataset = []
    with open(data_path, encoding="utf-8") as _fp:
        for _idx_l,  _line in enumerate(_fp):
            if _idx_l == 0:
                continue
            _raw_data = _line.strip().split("\t")  # remove the index
            sent_idx = int(_raw_data[0])
            if _raw_data[1] == "1":  # Sarcasm
                polarity = "negative"
            elif _raw_data[1] == "0":  # non-Sarcasm
                polarity = "neutral"
            else:
                raise AttributeError(data_path, _line, _raw_data)
            _sent = _raw_data[2]
            if "emoji" in data_path:
                _sent = process_tweet(_sent, remove_emoji=True, remove_user=True, remove_tag=True, replace_tag=True)
            else:
                _sent = process_tweet(_sent, remove_user=True, remove_tag=True, replace_tag=True)
            sample = {
                "sent_id": "sem-"+str(sent_idx), "sent_text": _sent,
                "terms": [{"term": None, "polarity": polarity, "from": -1, "to": -1}],
                "categories": [],
            }
            absa_dataset.append(sample)
    return absa_dataset


DATASET2PATH = {
    "rest14": "data/sentiment_analysis/SemEval-14",
    "lap14": "data/sentiment_analysis/SemEval-14",
    "twitter": "data/sentiment_analysis/twitter",
    "utstwitter": "data/sentiment_analysis/uts_data",
    "dohtwitter": "data/sentiment_analysis/doh_data",
    "sst3": "data/sentiment_analysis/stanfordSentimentTreebank",
    "sst2": "data/sentiment_analysis/stanfordSentimentTreebank",
    "sentiment140": "",
    "sarcasm": "data/sentiment_analysis/SemEval2018-Task3",
}


# DATASET2PATH = {
#     "rest14": os.path.join(USER_HOME, "Workspaces/dataset/ABSA/SemEval-14"),
#     "lap14": os.path.join(USER_HOME, "Workspaces/dataset/ABSA/SemEval-14"),
#     "twitter": os.path.join(USER_HOME, "Workspaces/dataset/ABSA/twitter"),
#     "utstwitter": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment"),
#     "dohtwitter": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment"),
#     "sst3": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank"),
#     "sst2": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank"),
#     "sentiment140": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment"),
#     "sarcasm": os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment/SemEval2018-Task3"),
# }


def get_raw_datasets(dataset, dataset_dir=None):
    if dataset == "rest14":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_path = os.path.join(dataset_dir, "Restaurants_Train_v2.xml")
        test_dataset_path = os.path.join(dataset_dir, "Restaurants_Test_Gold.xml")
        dev_dataset_path = test_dataset_path
        train_dataset_raw, dev_dataset_raw, test_dataset_raw = [
            read_semeval14_absa_xml(_p) for _p in [train_dataset_path, dev_dataset_path, test_dataset_path]]
    elif dataset == "lap14":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_path = os.path.join(dataset_dir, "Laptop_Train_v2.xml")
        test_dataset_path = os.path.join(dataset_dir, "Laptops_Test_Gold.xml")
        dev_dataset_path = test_dataset_path
        train_dataset_raw, dev_dataset_raw, test_dataset_raw = [
            read_semeval14_absa_xml(_p) for _p in [train_dataset_path, dev_dataset_path, test_dataset_path]]
    elif dataset == "twitter":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_path = os.path.join(dataset_dir, "train.raw")
        test_dataset_path = os.path.join(dataset_dir, "test.raw")
        dev_dataset_path = test_dataset_path
        train_dataset_raw, dev_dataset_raw, test_dataset_raw = [
            read_twitter_absa_dataset(_p) for _p in [train_dataset_path, dev_dataset_path, test_dataset_path]]
    elif dataset == "utstwitter":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        dataset_path = os.path.join(dataset_dir, "dev_wo_emoji.csv")
        dataset_raw = read_utstwitter_absa_dataset(dataset_path)
        train_dataset_raw = dev_dataset_raw = test_dataset_raw = dataset_raw
    elif dataset == "dohtwitter":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        dataset_path1 = os.path.join(dataset_dir, "DoH_dataset_1.csv")
        dataset_raw1 = read_dohtwitter_absa_dataset(dataset_path1)
        dataset_path2 = os.path.join(dataset_dir, "DoH_dataset_2.csv")
        dataset_raw2 = read_dohtwitter_absa_dataset(dataset_path2)
        dataset_raw = dataset_raw1 + dataset_raw2
        train_dataset_raw = dev_dataset_raw = test_dataset_raw = dataset_raw
    elif dataset == "sst3":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "train"))
        dev_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "dev"))
        test_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "test"))
    elif dataset == "sst2":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "train"), offset=0.0)
        dev_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "dev"), offset=0.0)
        test_dataset_raw = read_sst_normal_dataset(os.path.join(dataset_dir, "test"), offset=0.0)
    elif dataset == "sentiment140":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        dataset_raw = read_sentiment140_normal_dataset(os.path.join(dataset_dir, "training.1600000.processed.noemoticon.csv"))
        # sample
        sample_num = len(dataset_raw) // 8000
        dataset_raw = [ex for idx, ex in enumerate(dataset_raw) if idx%sample_num==0]
        train_dataset_raw = dev_dataset_raw = test_dataset_raw = dataset_raw
    elif dataset == "sarcasm":
        dataset_dir = dataset_dir or DATASET2PATH[dataset]
        train_dataset_raw = read_semeval2018task3_sarcasm_dataset(os.path.join(dataset_dir, "datasets/train/SemEval2018-T3-train-taskA.txt"))
        dev_dataset_raw = test_dataset_raw = read_semeval2018task3_sarcasm_dataset(os.path.join(dataset_dir, "datasets/goldtest_TaskA/SemEval2018-T3_gold_test_taskA_emoji.txt"))
    # OTHERS dataset fustion
    elif dataset == "twitter2doh":
        train_dataset_raw, _, twitter_raw_test = get_raw_datasets("twitter", dataset_dir=None)
        test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        dev_dataset_raw = test_dataset_raw
    elif dataset == "semeval142doh":
        rest14_raw, _, rest14_raw_test = get_raw_datasets("rest14", dataset_dir=None)
        lap14_raw, _, lap14_raw_test = get_raw_datasets("lap14", dataset_dir=None)
        train_dataset_raw = rest14_raw + lap14_raw
        test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        dev_dataset_raw = test_dataset_raw
    elif dataset in ["all2doh", "all2uts", "aall2doh", "aall2uts"]:
        rest14_raw, _, rest14_raw_test = get_raw_datasets("rest14", dataset_dir=None)
        lap14_raw, _, lap14_raw_test = get_raw_datasets("lap14", dataset_dir=None)
        twitter_raw, _, twitter_raw_test = get_raw_datasets("twitter", dataset_dir=None)
        train_dataset_raw = rest14_raw + lap14_raw + twitter_raw
        if dataset.startswith("aall2"):
            train_dataset_raw += rest14_raw_test + lap14_raw_test + twitter_raw_test
        if dataset in ["all2doh", "aall2doh"]:
            test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        elif dataset in ["all2uts", "aall2uts"]:
            test_dataset_raw, _, _ = get_raw_datasets("utstwitter", dataset_dir=None)
        else:
            raise NotImplementedError
        dev_dataset_raw = test_dataset_raw
    elif dataset in ["all2rest14", "all2lap14", "all2twitter"]:
        rest14_raw, _, rest14_raw_test = get_raw_datasets("rest14", dataset_dir=None)
        lap14_raw, _, lap14_raw_test = get_raw_datasets("lap14", dataset_dir=None)
        twitter_raw, _, twitter_raw_test = get_raw_datasets("twitter", dataset_dir=None)
        train_dataset_raw = rest14_raw + lap14_raw + twitter_raw
        if dataset == "all2rest14":
            dev_dataset_raw = test_dataset_raw = rest14_raw_test
        elif dataset == "all2lap14":
            dev_dataset_raw = test_dataset_raw = lap14_raw_test
        elif dataset == "all2twitter":
            dev_dataset_raw = test_dataset_raw = twitter_raw_test
        else:
            raise NotImplementedError
    elif dataset == "sent2doh-l":
        sst3_train_raw, sst3_dev_raw, sst3_test_raw = get_raw_datasets("sst3")
        sentiment140_train_raw, sentiment140_dev_raw, sentiment140_test_raw = get_raw_datasets("sentiment140")
        sarcasm_train_raw, sarcasm_dev_raw, sarcasm_test_raw = get_raw_datasets("sarcasm")
        train_dataset_raw = sst3_train_raw + sentiment140_train_raw + sarcasm_train_raw
        test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        dev_dataset_raw = test_dataset_raw
    elif dataset == "sent2doh-m":
        sst3_train_raw, sst3_dev_raw, sst3_test_raw = get_raw_datasets("sst3")
        sentiment140_train_raw, sentiment140_dev_raw, sentiment140_test_raw = get_raw_datasets("sentiment140")
        # sarcasm_train_raw, sarcasm_dev_raw, sarcasm_test_raw = get_raw_datasets("sarcasm")
        train_dataset_raw = sst3_train_raw + sentiment140_train_raw
        test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        dev_dataset_raw = test_dataset_raw
    elif dataset == "sent2doh-s":
        sst3_train_raw, sst3_dev_raw, sst3_test_raw = get_raw_datasets("sst3")
        # sentiment140_train_raw, sentiment140_dev_raw, sentiment140_test_raw = get_raw_datasets("sentiment140")
        sarcasm_train_raw, sarcasm_dev_raw, sarcasm_test_raw = get_raw_datasets("sarcasm")
        train_dataset_raw = sst3_train_raw + sarcasm_train_raw
        test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
        dev_dataset_raw = test_dataset_raw
    elif dataset in ["sst32doh", "sst32uts", "sst32twitter", "sst32rest14", "sst32lap14", ]:
        sst3_train_raw, sst3_dev_raw, sst3_test_raw = get_raw_datasets("sst3")
        # sentiment140_train_raw, sentiment140_dev_raw, sentiment140_test_raw = get_raw_datasets("sentiment140")
        # sarcasm_train_raw, sarcasm_dev_raw, sarcasm_test_raw = get_raw_datasets("sarcasm")
        train_dataset_raw = sst3_train_raw  # + sst3_dev_raw + sst3_test_raw  # todo: due to ausAI exp, comment the dev and test
        if dataset == "sst32doh":
            _, _, test_dataset_raw = get_raw_datasets("dohtwitter", dataset_dir=None)
        elif dataset == "sst32uts":
            _, _, test_dataset_raw = get_raw_datasets("utstwitter", dataset_dir=None)
        elif dataset == "sst32twitter":
            _, _, test_dataset_raw = get_raw_datasets("twitter", dataset_dir=None)
        elif dataset == "sst32rest14":
            _, _, test_dataset_raw = get_raw_datasets("rest14", dataset_dir=None)
        elif dataset == "sst32lap14":
            _, _, test_dataset_raw = get_raw_datasets("lap14", dataset_dir=None)
        else:
            raise NotImplementedError(dataset)

        dev_dataset_raw = test_dataset_raw
    # elif dataset == "psst32doh":
    #     dataset_dir = dataset_dir or os.path.join(USER_HOME, "Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank")
    #     train_dataset_raw = read_psst_normal_dataset(dataset_dir)
    #     test_dataset_raw, _, _ = get_raw_datasets("dohtwitter", dataset_dir=None)
    #     dev_dataset_raw = test_dataset_raw
    else:
        raise NotImplementedError(dataset, dataset_dir)
    return train_dataset_raw, dev_dataset_raw, test_dataset_raw


class AbsaDataset(Dataset):
    def __init__(
            self, absa_dataset, data_format, data_type, tokenizer, max_seq_length, concat_way="naive",
            *args, **kwargs):
        self.absa_dataset = absa_dataset
        self.data_format = data_format
        self.data_type = data_type
        self.tokenizer = tokenizer
        self.max_seq_length = max_seq_length

        self.concat_way = concat_way
        self.dataset_path = None

        # future arg -- to implement other opt
        self.standalone = True
        self.rm_conflict = True

        # begin to process
        self.example_list = []
        if data_format == "term":
            # with term as unit
            for sample in self.absa_dataset:
                for idx_term, term_dict in enumerate(sample["terms"]):
                    if self.rm_conflict and term_dict["polarity"] == "conflict":
                        continue
                    example = {
                        "sent_id": sample["sent_id"] + "-" + str(idx_term),
                        "sent_text": sample["sent_text"],
                        "terms": [term_dict],
                    }
                    self.example_list.append(example)
        elif data_format == "category":
            raise NotImplementedError
        else:
            raise AttributeError(data_format)

        # Misc
        self.sep_token, self.cls_token, self.pad_token = \
            self.tokenizer.sep_token, self.tokenizer.cls_token, self.tokenizer.pad_token
        self.sep_id, self.cls_id, self.pad_id = self.tokenizer.convert_tokens_to_ids(
            [self.sep_token, self.cls_token, self.pad_token],
        )

    def str2ids(self, text, max_len=None):
        text = self.tokenizer.cls_token + " " + text
        wps = self.tokenizer.tokenize(text)
        if max_len is not None:
            wps = self.tokenizer.tokenize(text)[:max_len-1]
        wps.append(self.tokenizer.sep_token)
        return self.tokenizer.convert_tokens_to_ids(wps)

    def __getitem__(self, item):
        example = self.example_list[item]

        aspect_term = example["terms"][0]["term"]
        polarity = example["terms"][0]["polarity"]
        sent_text = example["sent_text"]

        if self.concat_way == "naive":
            aspect_term_ids = self.str2ids(aspect_term, max_len=16)
            sent_ids = self.str2ids(sent_text, max_len=self.max_seq_length-len(aspect_term_ids)+1)
            input_ids = aspect_term_ids + sent_ids[1:]
            segment_ids = [0]*len(aspect_term_ids) + [1]*len(sent_ids[1:])
        elif self.concat_way == "qam":
            aspect_term_ids = self.str2ids("What do you think of the " + aspect_term, max_len=22)
            sent_ids = self.str2ids(sent_text, max_len=self.max_seq_length-len(aspect_term_ids)+1)
            input_ids = sent_ids + aspect_term_ids[1:]
            segment_ids = [0]*len(sent_ids) + [1]*len(aspect_term_ids[1:])
        elif self.concat_way == "seg_id":
            from_idx = example["terms"][0]["from"]
            to_idx = example["terms"][0]["to"]
            sent_tokens = split_to_token(self.tokenizer, sent_text)
            charidx2tokenidx = parse_tk_idx_list_wrt_char(self.tokenizer, sent_text, sent_tokens)
            token_from_idx, token_to_idx = char_to_token_span(charidx2tokenidx, from_idx, to_idx)
            wp_list, id_list, pos_list = continue_tokenize_for_wordpiece(self.tokenizer, sent_tokens)
            term_mask = [1 if token_from_idx <= _pos < token_to_idx else 0 for _pos in pos_list]
            input_ids = [self.cls_id] + id_list + [self.sep_id]
            segment_ids = [0] + term_mask + [0]
        elif self.concat_way == "sent":
            input_ids = self.str2ids(sent_text, max_len=self.max_seq_length)
            segment_ids = [0]*len(input_ids)
        else:
            raise NotImplementedError
        mask_ids = [1] * len(input_ids)

        # label
        if polarity == "negative":
            label = 0
        elif polarity == "neutral":
            label = 1
        elif polarity == "positive":
            label = 2
        else:
            raise AttributeError(polarity)

        return torch.tensor(input_ids, dtype=torch.long), torch.tensor(mask_ids, dtype=torch.long), \
               torch.tensor(segment_ids, dtype=torch.long), torch.tensor(label, dtype=torch.long),

    def data_collate_fn(self, batch):
        tensors_list = list(zip(*batch))
        return_list = []
        for _idx_t, _tensors in enumerate(tensors_list):
            if _idx_t == 0:
                padding_value = self.pad_id
            else:
                padding_value = 0

            if _tensors[0].dim() >= 1:
                _tensors = [_t.t() for _t in _tensors]
                return_list.append(
                    torch.nn.utils.rnn.pad_sequence(
                        _tensors, batch_first=True, padding_value=padding_value),  # .transpose(-1, -2)
                )
            else:
                return_list.append(torch.stack(_tensors, dim=0))
        return tuple(return_list)

    @classmethod
    def batch2feed_dict(cls, batch, data_format=None):
        inputs = {
            'input_ids': batch[0],  # bs, sl
            'attention_mask': batch[1],  #
            'token_type_ids': batch[2],  #
            "labels": batch[-1],  #
        }
        return inputs

    def __len__(self):
        return len(self.example_list)


if __name__ == '__main__':
    # ds1 = read_semeval14_absa_xml("/home/tshen/Workspaces/dataset/ABSA/SemEval-14/Restaurants_Train_v2.xml")
    # ds2 = read_twitter_absa_dataset("/home/tshen/Workspaces/dataset/ABSA/twitter/train.raw")
    # ds3 = read_utstwitter_absa_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/dev_wo_emoji.csv")
    # ds4 = read_dohtwitter_absa_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/DoH_dataset_1.csv")
    # ds5 = read_sentiment140_normal_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/training.1600000.processed.noemoticon.csv")
    # ds6a = read_sst_normal_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank/train")
    # ds6b = read_sst_normal_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank/dev")
    # ds6c = read_sst_normal_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank/test")
    # ds7 = read_semeval2018task3_sarcasm_dataset(USER_HOME + "/Workspaces/dataset/projects/sentiment/SemEval2018-Task3/datasets/train/SemEval2018-T3-train-taskA.txt")
    ds8 = read_psst_normal_dataset("/home/tshen/Workspaces/dataset/projects/sentiment/stanfordSentimentTreebank")

    anchor = 0


















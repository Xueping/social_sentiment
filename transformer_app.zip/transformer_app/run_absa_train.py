from absa.absa_train import main

if __name__ == '__main__':
    main()

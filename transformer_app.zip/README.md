# Sentiment Analysis System

## Instruction of Env Installation

### CUDA and Env Variables

**Please make sure CUDA version is 10.0** 

```
# CUDA ENV -- copy to ~/.bashrc
export CUDA_HOME="/usr/local/cuda-10.0/"
export PATH="$CUDA_HOME/bin:$PATH"
export CPATH="$CUDA_HOME/include:$CPATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"
export DYLD_LIBRARY_PATH="$CUDA_HOME/lib:$DYLD_LIBRARY_PATH"
```


### CONDA Env

conda create -n venv python=3.6
source activate venv

conda install -y pytorch=1.2 torchvision -c pytorch
conda install -y -c conda-forge spacy=2.0.16; python -m spacy download en; pip install spacy-langdetect
pip install regex tqdm scipy fuzzywuzzy tensorboardX nltk python-Levenshtein scikit-learn gensim pandas boto3 sacremoses sentencepiece 
pip install wordsegment

#### APEX Installation

**Using [apex](https://github.com/NVIDIA/apex) package for mixed float computation, which double the inference speed.**

Note: In my experience, the newest version is not very compatible with pytorch 1.2 and cuda-10, please use the verified version in [here](https://github.com/NVIDIA/apex/tree/50338df6280fd47832039725ec5bdcc202591222). Or follow the steps below:
```
git clone https://github.com/NVIDIA/apex/tree/50338df6280fd47832039725ec5bdcc202591222
cd apex
pip install -v --no-cache-dir --global-option="--cpp_ext" --global-option="--cuda_ext" ./
```


## Guide to Use

### Model Inference

1. Config Model Path: Fill model dir(s) at `absa/projs/configs.py`
2. Use the interface in `absa/projs/inference.py`
    * We give an running example at `sentiment_analysis_example.py`
    * We also detail the API in `absa/projs/configs.py`

### Model Training

This also available at `sentiment_analysis_training.sh`.

```
export CUDA_VISIBLE_DEVICES=0

OPT_PARAM="--adam_betas 0.9,0.98 --adam_epsilon 1e-6 --max_grad_norm 0. --weight_decay 0.01 --warmup_proportion 0.05"
LR=1e-5
NUM_STEP=3
EVAL_STEP=256
BATCH_SIZE=32
MODEL_CLASS="roberta"
MODEL_DIR="roberta-large"
SEED=21

# Sentence-level sentiment analysis model
SLSA_OUT_DIR="!!!config!!!"
DATASET="sst32doh"
CONCAT_WAY="sent"
python3 run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
  $OPT_PARAM \
  --learning_rate $LR --num_train_epochs $NUM_STEP \
  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
  --eval_batch_size 32 --logging_step 10 \
  --gradient_accumulation_steps 1 \
  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
  --output_dir $SLSA_OUT_DIR \
  --seed $SEED \
  --concat_way $CONCAT_WAY \
  --fp16

# Aspect-based sentiment analysis model
ABSA_OUT_DIR="!!!config!!!"
DATASET="all2doh"
CONCAT_WAY="naive"
python3 run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
  $OPT_PARAM \
  --learning_rate $LR --num_train_epochs $NUM_STEP \
  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
  --eval_batch_size 32 --logging_step 10 \
  --gradient_accumulation_steps 1 \
  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
  --output_dir $ABSA_OUT_DIR \
  --seed $SEED \
  --concat_way $CONCAT_WAY \
  --fp16

# Sarcasm detection model
SARCASM_OUT_DIR="!!!config!!!"
DATASET="sarcasm"
CONCAT_WAY="sent"
python3 run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
  $OPT_PARAM \
  --learning_rate $LR --num_train_epochs $NUM_STEP \
  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
  --eval_batch_size 32 --logging_step 10 \
  --gradient_accumulation_steps 1 \
  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
  --output_dir $SARCASM_OUT_DIR \
  --seed $SEED \
  --concat_way $CONCAT_WAY \
  --fp16

```


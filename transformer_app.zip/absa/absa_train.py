import argparse
from tqdm import tqdm, trange
import pandas as pd
import time
from peach.help import *
from absa.absa_dataset import AbsaDataset, get_raw_datasets
from transformers import RobertaConfig, RobertaTokenizer, RobertaForSequenceClassification
from transformers import BertConfig, BertTokenizer, BertForSequenceClassification


def evaluate(
        args, eval_dataset, model, tokenizer, global_step,
        is_saving_pred=False, verbose=False, file_prefix=""):
    logging.info("***** Running evaluation at {}*****".format(global_step))
    logging.info("  Num examples = %d", len(eval_dataset))
    logging.info("  Batch size = %d", args.eval_batch_size)
    eval_dataloader = setup_eval_step(
        args, eval_dataset, collate_fn=eval_dataset.data_collate_fn, )
    model.eval()
    eval_loss, eval_accuracy = 0, 0
    nb_eval_steps, nb_eval_examples = 0, 0

    _idx_ex = 0
    labels_list = []
    confs_list = []
    for batch in tqdm(eval_dataloader, desc="Evaluating"):
        batch = tuple(_t.to(args.device) for _t in batch)
        feed_dict = eval_dataset.batch2feed_dict(batch)
        if args.model_class == "roberta":
            feed_dict.pop("token_type_ids")
        with torch.no_grad():
            outputs = model(**feed_dict)
            tmp_eval_loss, confs = outputs[:2]
            confs = torch.softmax(confs, dim=-1)

        eval_loss += tmp_eval_loss.mean().item()

        labels_list.append(feed_dict["labels"].detach().cpu().numpy())
        confs_list.append(confs.detach().cpu().numpy())

        nb_eval_examples += feed_dict["input_ids"].size(0)
        nb_eval_steps += 1
    eval_loss = eval_loss / nb_eval_steps
    labels = np.concatenate(labels_list, axis=0).astype("int64")
    confs = np.concatenate(confs_list, axis=0)

    preds = np.argmax(confs, axis=-1)   # (confs[:,1] > thresh).astype("int64")
    accu = np.mean(labels == preds)

    # accu = metrics.accuracy_score(labels, preds)
    import sklearn
    recall = sklearn.metrics.recall_score(labels, preds, average="macro")
    precision = sklearn.metrics.precision_score(labels, preds, average="macro")
    f1 = sklearn.metrics.f1_score(labels, preds, average="macro")

    result = {
        'eval_loss': eval_loss,
        "accuracy": accu,
        "recall": recall,
        "precision": precision,
        "f1": f1
    }
    output_eval_file = os.path.join(args.output_dir, file_prefix + "eval_results.txt")
    with open(output_eval_file, "a") as writer:
        logging.info("***** Eval results at {}*****".format(global_step))
        writer.write("***** Eval results at {}*****\n".format(global_step))
        for key in sorted(result.keys()):
            logging.info("  %s = %s", key, str(result[key]))
            writer.write("%s = %s\n" % (key, str(result[key])))
        writer.write("\n")

    if is_saving_pred:
        sent_id_list = []
        sent_text_list = []
        term_list = []
        for absa_example in eval_dataset.example_list:
            sent_id_list.append(absa_example["sent_id"])
            sent_text_list.append(absa_example["sent_text"])
            term_list.append(absa_example["terms"][0]["term"] or "")

        assert len(sent_id_list) == labels.shape[0] == confs.shape[0]
        pred_data = {
            "sent_id": sent_id_list,
            "sent_text": sent_text_list,
            "term": term_list,
            "label": labels,
            "negative": confs[:, 0],
            "neutral": confs[:, 1],
            "positive": confs[:, 2],
        }
        pred_data_df = pd.DataFrame(pred_data)
        pred_data_df.to_csv(os.path.join(args.output_dir, file_prefix + "pred_data.csv"))
    return f1


def train(args, train_dataset, model, tokenizer, eval_dataset=None, eval_fn=None):
    """ Train the model """
    if args.local_rank in [-1, 0]:
        tb_writer = SummaryWriter()

    # learning setup
    train_dataloader = setup_training_step(
        args, train_dataset, collate_fn=train_dataset.data_collate_fn)
    model, optimizer, scheduler = setup_opt(args, model)

    # Train!
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_dataset))
    logger.info("  Num Epochs = %d", args.num_train_epochs)
    logger.info("  Gradient Accumulation steps = %d", args.gradient_accumulation_steps)
    logger.info("  Total optimization steps = %d", args.t_total)

    global_step = 0
    best_accu = -1e5
    ma_dict = MovingAverageDict()
    model.zero_grad()
    epoch_duration = 0.0
    train_iterator = trange(int(args.num_train_epochs), desc="Epoch", disable=args.local_rank not in [-1, 0])
    set_seed(args)  # Added here for reproductibility (even between python 2 and 3)
    for _idx_epoch in train_iterator:
        start_time = time.time()
        epoch_iterator = tqdm(train_dataloader,
                              desc="Iteration-{}({})".format(_idx_epoch, args.gradient_accumulation_steps),
                              disable=args.local_rank not in [-1, 0])
        step_loss = 0
        for step, batch in enumerate(epoch_iterator):
            model.train()
            batch = tuple(t.to(args.device) for t in batch)
            # assert len(batch) == 5
            feed_dict = train_dataset.batch2feed_dict(batch)
            if args.model_class == "roberta":
                feed_dict.pop("token_type_ids")
            outputs = model(**feed_dict)
            loss = outputs[0]  # model outputs are always tuple in pytorch-transformers (see doc)
            loss = update_wrt_loss(args, model, optimizer, loss)

            step_loss += loss.item()

            if (step + 1) % args.gradient_accumulation_steps == 0:
                model_update_wrt_gradient(args, model, optimizer, scheduler)
                global_step += 1
                # update loss for logging
                ma_dict({"loss": step_loss})
                step_loss = 0.

                if args.local_rank in [-1, 0] and args.logging_steps > 0 and global_step % args.logging_steps == 0:
                    logging.info(ma_dict.get_val_str())

                if args.local_rank in [-1, 0] and args.save_steps > 0 and global_step % args.save_steps == 0:
                    save_model_with_default_name(args.output_dir, model, tokenizer, args)

                if eval_dataset is not None and args.eval_steps > 0 and global_step % args.eval_steps == 0:
                    cur_accu = eval_fn(args, eval_dataset, model, tokenizer, global_step=global_step)
                    if cur_accu > best_accu:
                        best_accu = cur_accu
                        save_model_with_default_name(args.output_dir, model, tokenizer, args_to_save=args)

                if args.max_steps > 0 and global_step > args.max_steps:
                    epoch_iterator.close()
                    break
        # evaluation each epoch or last epoch
        if (_idx_epoch == int(args.num_train_epochs) - 1) or (eval_dataset is not None and args.eval_steps <= 0):
            cur_accu = eval_fn(args, eval_dataset, model, tokenizer, global_step=global_step)
            if cur_accu > best_accu:
                best_accu = cur_accu
                save_model_with_default_name(args.output_dir, model, tokenizer, args_to_save=args)

        if args.max_steps > 0 and global_step > args.max_steps:
            train_iterator.close()
            break

        with open(os.path.join(args.output_dir, "best_eval_results.txt"), "w") as fp:
            fp.write("{}{}".format(best_accu, os.linesep))
        duration = time.time() - start_time
        buf = '{} Epoch {}: Training complete in {:.0f}m {:.0f}s'.format(time.strftime('%Y-%m-%d %H:%M:%S',
                                                                                       time.localtime()),
                                                               _idx_epoch, epoch_duration // 60, epoch_duration % 60)
        logger.info(buf)

        epoch_duration += duration
    buf = '{} Training complete in {:.0f}m {:.0f}s'.format(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                                                           epoch_duration // 60, epoch_duration % 60)
    logger.info(buf)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_class", default="roberta", type=str, help="[roberta|]")
    parser.add_argument("--dataset", default="rest14", type=str, help="[rest14|lap14|twitter]")
    parser.add_argument("--dataset_dir", default=None, type=str, help="")
    parser.add_argument("--concat_way", default="naive", type=str, help="")
    parser.add_argument("--model_name_or_path", default=None, type=str, required=True,
                        help="Path to pre-trained model or shortcut name selected in the list: " + ", ".join(
                            ALL_MODELS))
    parser.add_argument("--output_dir", default=None, type=str, required=True,
                        help="The output directory where the model checkpoints will be written.")
    define_hparams_training(parser)
    args = parser.parse_args()

    setup_prerequisite(args)

    # Load pretrained model and tokenizer
    if args.local_rank not in [-1, 0]:
        torch.distributed.barrier()  # Make sure only the first process in distributed training will download model & vocab

    if args.model_class == "bert":
        model_class = BertForSequenceClassification
        config_class = BertConfig
        tokenizer_class = BertTokenizer
    elif args.model_class == "roberta":
        model_class = RobertaForSequenceClassification
        config_class = RobertaConfig
        tokenizer_class = RobertaTokenizer
    else:
        raise NotImplementedError

    config = config_class.from_pretrained(args.config_name if args.config_name else args.model_name_or_path)
    config.num_labels = 3  # todo: become dynamic
    tokenizer = tokenizer_class.from_pretrained(
        args.tokenizer_name if args.tokenizer_name else args.model_name_or_path, do_lower_case=args.do_lower_case)
    model = model_class.from_pretrained(args.model_name_or_path, config=config)

    if args.local_rank == 0:
        torch.distributed.barrier()  # Make sure only the first process in distributed training will download model & vocab
    model.to(args.device)
    logger.info("Training/evaluation parameters %s", args)

    train_dataset_raw, dev_dataset_raw, test_dataset_raw = get_raw_datasets(
        args.dataset, args.dataset_dir)
    train_dataset = AbsaDataset(train_dataset_raw, "term", "train", tokenizer, args.max_seq_length, concat_way=args.concat_way)
    dev_dataset = AbsaDataset(dev_dataset_raw, "term", "dev", tokenizer, args.max_seq_length, concat_way=args.concat_way)
    test_dataset = AbsaDataset(test_dataset_raw, "term", "test", tokenizer, args.max_seq_length, concat_way=args.concat_way)

    if args.do_train:
        train(args, train_dataset, model, tokenizer, dev_dataset, eval_fn=evaluate)

    if args.do_eval or args.do_prediction:
        if args.do_train:
            model = model_class.from_pretrained(args.output_dir, config=config)
            model.to(args.device)
        if args.fp16:
            model = setup_eval_model_for_fp16(args, model)

        evaluate(args, dev_dataset, model, tokenizer, global_step=None, verbose=True, file_prefix="final_dev_", is_saving_pred=True)
        evaluate(args, test_dataset, model, tokenizer, global_step=None, verbose=True, file_prefix="final_test_", is_saving_pred=True)


if __name__ == '__main__':
    main()

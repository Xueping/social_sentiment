from peach.utils_project import SentClsInterface
from peach.utils_twitter import process_tweet
from absa.projs.configs import model_dir_dict
import numpy as np


class SentimenAnalysisSystem(object):
    pred_int2str = {
        0: "negative",
        1: "neutral",
        2: "positive",
    }

    def __init__(self, use_cuda=True, use_fp16=True):
        """
        Build a system from pre-set model dir
        :param use_cuda: Use GPU (recommend)
        :param use_fp16: Use FP16 (recommend)
        """
        self.slsa_model, self.absa_model, self.sd_model = None, None, None
        # sentment-level sentiment analysis model
        self.slsa_model = SentClsInterface(
            model_dir_dict["slsa"], use_cuda=use_cuda, use_fp16=use_fp16, batch_size=32)
        # aspect-based sentiment analysis model
        if model_dir_dict["absa"]:
            self.absa_model = SentClsInterface(
                model_dir_dict["absa"], use_cuda=use_cuda, use_fp16=use_fp16, batch_size=16)
        # sarcasm detection model
        if model_dir_dict["sd"]:
            self.sd_model = SentClsInterface(
                model_dir_dict["sd"], use_cuda=use_cuda, use_fp16=use_fp16, batch_size=32)

    def predict_polarity(self, sent_list, term_list=None, use_slsa=True, use_absa=True, use_sd=True, verbose=False):
        """
        Sentiment classification API. If both use_absa and use_slsa are set to positive, an ensemble approach will be applied.
        :param sent_list: A list of str to predict their polarity
        :param term_list: A list of aspect terms corresponding to sent_list. if use_absa is set to false, this will be ignored.
        :param use_slsa: use sententce-level sentiment analysis model
        :param use_absa: use apsect-based sentiment analysis model
        :param use_sd: use sarcasm detection model
        :param verbose: verbose the prediction process
        :return: a list of string polarity label in [positive, neutral, negative]
        """
        # sannity check
        assert (not use_absa) or self.absa_model is not None, "absa_model is invalid, please check the config"
        assert (not use_sd) or self.sd_model is not None, "sd_model is invalid, please check the config"
        assert use_slsa or use_absa, "Must choose at least one of slsa and absa"
        assert (not use_absa) or (isinstance(term_list, list) and len(sent_list)==len(term_list)), \
            "if enable absa, please feed the term corresponding to each sentence"

        sent_list = [
            process_tweet(sent, remove_emoji=True, remove_user=True, remove_tag=True, replace_tag=True)
            for sent in sent_list]

        if use_slsa:
            slsa_probs = self.slsa_model.classify_sents(sent_list, verbose=verbose)
        else:
            slsa_probs = None

        if use_absa:
            absa_probs = self.absa_model.classify_sents([[t, s] for t, s in zip(term_list, sent_list)], verbose=verbose)
        else:
            absa_probs = None

        if use_slsa and use_absa:
            preds = np.argmax(np.concatenate([slsa_probs, absa_probs], axis=-1), axis=-1) % slsa_probs.shape[1]
        else:
            if use_slsa:
                preds = np.argmax(slsa_probs, axis=-1)
            elif use_absa:
                preds = np.argmax(absa_probs, axis=-1)
            else:
                raise RuntimeError

        if use_sd:
            sd_probs = self.sd_model.classify_sents(sent_list, verbose=verbose)
            sarcasm_conf = sd_probs[:, 0]
            sarcasm_mask = sarcasm_conf > 0.9  # here is a hyperparameter
            preds = preds * (1 - sarcasm_mask.astype("int64"))  # force to zero for sarcasm sentence

        # prepare returns
        pred_list = [self.pred_int2str[p] for p in preds]

        return pred_list

if __name__ == '__main__':
    pass

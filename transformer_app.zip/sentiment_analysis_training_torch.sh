#!/bin/bash

export CUDA_VISIBLE_DEVICES=0

OPT_PARAM="--adam_betas 0.9,0.98 --adam_epsilon 1e-6 --max_grad_norm 0. --weight_decay 0.01 --warmup_proportion 0.05"
LR=1e-5
NUM_STEP=3
EVAL_STEP=256
BATCH_SIZE=16
MODEL_CLASS="roberta"
MODEL_DIR="roberta-large"
SEED=21

# Sentence-level sentiment analysis model
SLSA_OUT_DIR="sentence_level_1"
#SLSA_OUT_DIR="!!!config!!!"
DATASET="sst32doh"
CONCAT_WAY="sent"
~/anaconda3.7/envs/pytorch-1.4/bin/python3 run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
  $OPT_PARAM \
  --learning_rate $LR --num_train_epochs $NUM_STEP \
  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
  --eval_batch_size 32 --logging_step 10 \
  --gradient_accumulation_steps 1 \
  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
  --output_dir $SLSA_OUT_DIR \
  --seed $SEED \
  --concat_way $CONCAT_WAY \
#  --fp16

# Aspect-based sentiment analysis model
#ABSA_OUT_DIR="!!!config!!!"
ABSA_OUT_DIR="aspect_sent_1"
DATASET="all2doh"
CONCAT_WAY="naive"
~/anaconda3.7/envs/pytorch-1.4/bin/python3 run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
  $OPT_PARAM \
  --learning_rate $LR --num_train_epochs $NUM_STEP \
  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
  --eval_batch_size 32 --logging_step 10 \
  --gradient_accumulation_steps 1 \
  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
  --output_dir $ABSA_OUT_DIR \
  --seed $SEED \
  --concat_way $CONCAT_WAY \
#  --fp16

## Sarcasm detection model
#SARCASM_OUT_DIR="!!!config!!!"
#DATASET run_absa_train.py --dataset $DATASET --do_train --do_eval --max_seq_length 64 \
#  $OPT_PARAM \
#  --learning_rate $LR --num_train_epochs $NUM_STEP \
#  --eval_step $EVAL_STEP --train_batch_size $BATCH_SIZE \
#  --eval_batch_size 32 --logging_step 10 \
#  --gradient_accumulation_steps 1 \
#  --model_class $MODEL_CLASS --model_name_or_path $MODEL_DIR \
#  --output_dir $SARCASM_OUT_DIR \
#  --seed $SEED \
#  --concat_way $CONCAT_WAY \
#  --fp16


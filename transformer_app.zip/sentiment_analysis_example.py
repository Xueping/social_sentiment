from absa.projs.inference import SentimenAnalysisSystem


if __name__ == '__main__':
    sas = SentimenAnalysisSystem()

    sents = [
        "The food is ok, but service is bad",
        "The food is ok, but service is bad",
        "I feel good",
        "I feel bad",
    ]
    terms = [
        "food",
        "service",
        "",
        "",
    ]
    print(sas.predict_polarity(
        sents,
        terms,
        use_slsa=True, use_absa=True, use_sd=False, verbose=True
    ))
    print(sas.predict_polarity(
        sents,
        terms,
        use_slsa=True, use_absa=False, use_sd=False, verbose=True
    ))
    print(sas.predict_polarity(
        sents,
        terms,
        use_slsa=False, use_absa=True, use_sd=False, verbose=True
    ))
